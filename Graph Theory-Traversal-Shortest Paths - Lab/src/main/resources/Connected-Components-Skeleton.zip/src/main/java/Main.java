import java.util.Collection;
import java.util.Deque;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {

    }

    public static List<Deque<Integer>> getConnectedComponents(List<List<Integer>> graph) {
        throw new AssertionError("Not Implemented");
    }

    public static Collection<String> topSort(Map<String, List<String>> graph) {
        throw new AssertionError("Not Implemented");
    }
}
